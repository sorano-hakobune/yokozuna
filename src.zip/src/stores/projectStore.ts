import { create } from "zustand";
import type {
  Project,
  Composition,
  Layer,
  Keyframe,
  Element,
  Symbol,
  Asset,
  ProjectSettings,
} from "@/types/project";
import { createEmptyProject, generateId } from "@/lib/project";

interface ProjectState {
  project: Project;
  currentFrame: number;
  selectedLayerId?: string;
  selectedElementId?: string;
  clipboard: any | null;
  canvasZoom: number;
  canvasPan: { x: number; y: number };

  // ---- 描画ツール ----
  selectedTool: "select" | "rectangle" | "circle" | "line";
  setSelectedTool: (tool: "select" | "rectangle" | "circle" | "line") => void;
  setSelectedElementId: (elementId?: string) => void;
  copyElement: (layerId: string, frame: number, elementId: string) => void;
  pasteElement: (layerId: string, frame: number) => void;
  setCanvasZoom: (zoom: number) => void;
  setCanvasPan: (pan: { x: number; y: number }) => void;

  // ---- 基本操作 ----
  createNewProject: (name?: string) => void;
  loadProject: (project: Project) => void;
  setProject: (project: any) => void;
  updateMeta: (partial: Partial<Project["meta"]>) => void;
  updateSettings: (partial: Partial<ProjectSettings>) => void;
  setCurrentFrame: (frame: number) => void;

  // ---- コンポジション ----
  setActiveComposition: (compositionId: string) => void;
  addComposition: (name?: string) => string;

  // ---- レイヤー ----
  addLayer: (name?: string) => string;
  updateLayer: (
    layerId: string,
    partial: Partial<Pick<Layer, "name" | "visible" | "locked" | "type">>,
  ) => void;
  removeLayer: (layerId: string) => void;
  reorderLayers: (layerIds: string[]) => void;

  // ---- キーフレーム ----
  addKeyframe: (
    layerId: string,
    frame: number,
    elements?: Element[],
  ) => void;
  updateKeyframe: (
    layerId: string,
    frame: number,
    partial: Partial<any>,
  ) => void;
  removeKeyframe: (
    layerId: string,
    frame: number,
  ) => void;
  moveKeyframe: (
    layerId: string,
    fromFrame: number,
    toFrame: number,
  ) => void;

  // ---- 要素（Element） ----
  updateElement: (
    layerId: string,
    frame: number,
    elementId: string,
    partial: Partial<Element>,
  ) => void;
  addShapeToLayer: (
    layerId: string,
    frame: number,
    shape: any,
  ) => void;
  removeElement: (
    layerId: string,
    frame: number,
    elementId: string,
  ) => void;
  addBitmapElement: (
    layerId: string,
    frame: number,
    assetId: string,
    x: number,
    y: number,
  ) => void;

  // ---- シンボル・アセット ----
  addAsset: (asset: Omit<Asset, "id">) => string;
  addSymbol: (symbol: Omit<Symbol, "id">) => string;
}

export const useProjectStore = create<ProjectState>((set, get) => ({
  project: createEmptyProject(),
  currentFrame: 0,
  selectedLayerId: undefined,
  selectedElementId: undefined,
  clipboard: null,
  canvasZoom: 1,
  canvasPan: { x: 0, y: 0 },
  selectedTool: "select",

  // ======================
  // 描画ツール
  // ======================
  setSelectedTool: (tool) => set({ selectedTool: tool }),
  setSelectedElementId: (elementId) => set({ selectedElementId: elementId }),
  setCurrentFrame: (frame) => set({ currentFrame: frame }),
  setCanvasZoom: (zoom) => set({ canvasZoom: zoom }),
  setCanvasPan: (pan) => set({ canvasPan: pan }),
  copyElement: (layerId, frame, elementId) => {
    const compositionId = get().project.activeCompositionId;
    const comp = get().project.compositions[compositionId];
    if (!comp) return;

    const layer = comp.layers.find((l) => l.id === layerId);
    if (!layer) return;

    const keyframe = layer.keyframes.find((kf) => kf.frame === frame);
    if (!keyframe) return;

    const element = keyframe.elements.find((el) => el.id === elementId);
    if (!element) return;

    set({ clipboard: JSON.parse(JSON.stringify(element)) });
  },
  pasteElement: (layerId, frame) => {
    const clipboard = get().clipboard;
    if (!clipboard) return;

    const compositionId = get().project.activeCompositionId;
    const comp = get().project.compositions[compositionId];
    if (!comp) return;

    const newElement = {
      ...JSON.parse(JSON.stringify(clipboard)),
      id: generateId("element"),
      x: (clipboard.x ?? 0) + 20, // 少しずらしてペースト
      y: (clipboard.y ?? 0) + 20,
    };

    set((state) => ({
      project: {
        ...state.project,
        compositions: {
          ...state.project.compositions,
          [compositionId]: {
            ...comp,
            layers: comp.layers.map((layer) => {
              if (layer.id !== layerId) return layer;

              return {
                ...layer,
                keyframes: layer.keyframes.map((kf) => {
                  if (kf.frame !== frame) return kf;

                  return {
                    ...kf,
                    elements: [...kf.elements, newElement],
                  };
                }),
              };
            }),
          },
        },
        meta: {
          ...state.project.meta,
          modifiedAt: new Date().toISOString(),
        },
      },
    }));
  },

  // ======================
  // 基本操作
  // ======================
  createNewProject: (name) => {
    set({ project: createEmptyProject(name) });
  },

  loadProject: (project) => {
    set({ project });
  },

  setProject: (project) => set({ project }),

  updateMeta: (partial) => {
    set((state) => ({
      project: {
        ...state.project,
        meta: {
          ...state.project.meta,
          ...partial,
          modifiedAt: new Date().toISOString(),
        },
      },
    }));
  },

  updateSettings: (partial) => {
    set((state) => ({
      project: {
        ...state.project,
        settings: {
          ...state.project.settings,
          ...partial,
        },
        meta: {
          ...state.project.meta,
          modifiedAt: new Date().toISOString(),
        },
      },
    }));
  },

  // ======================
  // コンポジション
  // ======================
  setActiveComposition: (compositionId) => {
    set((state) => ({
      project: {
        ...state.project,
        activeCompositionId: compositionId,
      },
    }));
  },

  addComposition: (name = "New Composition") => {
    const id = generateId("comp");
    const newComp: Composition = {
      id,
      name,
      duration: get().project.settings.duration,
      layers: [
        {
          id: generateId("layer"),
          name: "Layer 1",
          type: "normal",
          visible: true,
          locked: false,
          keyframes: [
            {
              frame: 0,
              tween: "none",
              elements: [],
            },
          ],
        },
      ],
    };

    set((state) => ({
      project: {
        ...state.project,
        compositions: {
          ...state.project.compositions,
          [id]: newComp,
        },
        activeCompositionId: id,
        meta: {
          ...state.project.meta,
          modifiedAt: new Date().toISOString(),
        },
      },
    }));

    return id;
  },

  // ======================
  // レイヤー
  // ======================
  addLayer: (name = "New Layer") => {
    const id = generateId("layer");
    const newLayer: Layer = {
      id,
      name,
      type: "normal",
      visible: true,
      locked: false,
      keyframes: [
        {
          frame: 0,
          tween: "none",
          elements: [],
        },
      ],
    };

    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: [...comp.layers, newLayer],
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });

    return id;
  },

  updateLayer: (layerId, partial) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) =>
                layer.id === layerId ? { ...layer, ...partial } : layer,
              ),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  removeLayer: (layerId) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.filter((l) => l.id !== layerId),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  reorderLayers: (layerIds) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      const layerMap = new Map(comp.layers.map((l) => [l.id, l]));
      const newLayers = layerIds
        .map((id) => layerMap.get(id))
        .filter((l): l is Layer => !!l);

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: newLayers,
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  // ======================
  // キーフレーム
  // ======================
  addKeyframe: (layerId, frame, elements = []) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                // 既に同じフレームのキーフレームがある場合は何もしない
                if (layer.keyframes.some((kf) => kf.frame === frame)) {
                  return layer;
                }

                const newKeyframe: Keyframe = {
                  frame,
                  tween: "none",
                  elements,
                };

                const newKeyframes = [...layer.keyframes, newKeyframe].sort(
                  (a, b) => a.frame - b.frame,
                );

                return {
                  ...layer,
                  keyframes: newKeyframes,
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  updateKeyframe: (layerId, frame, partial) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                return {
                  ...layer,
                  keyframes: layer.keyframes.map((kf) =>
                    kf.frame === frame ? { ...kf, ...partial } : kf,
                  ),
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  removeKeyframe: (layerId, frame) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                // フレーム0のキーフレームは削除しない（最低1つ残す）
                if (frame === 0 && layer.keyframes.length <= 1) {
                  return layer;
                }

                return {
                  ...layer,
                  keyframes: layer.keyframes.filter((kf) => kf.frame !== frame),
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  moveKeyframe: (layerId, fromFrame, toFrame) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                // 移動先に既にキーフレームがある場合は何もしない
                if (layer.keyframes.some((kf) => kf.frame === toFrame)) {
                  return layer;
                }

                const newKeyframes = layer.keyframes
                  .map((kf) =>
                    kf.frame === fromFrame ? { ...kf, frame: toFrame } : kf,
                  )
                  .sort((a, b) => a.frame - b.frame);

                return {
                  ...layer,
                  keyframes: newKeyframes,
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  // ======================
  // 要素
  // ======================
  updateElement: (layerId, frame, elementId, partial) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                return {
                  ...layer,
                  keyframes: layer.keyframes.map((kf) => {
                    if (kf.frame !== frame) return kf;

                    return {
                      ...kf,
                      elements: kf.elements.map((el) =>
                        el.id === elementId
                          ? ({ ...el, ...partial } as Element)
                          : el,
                      ),
                    };
                  }),
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  addShapeToLayer: (layerId, frame, shape) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                return {
                  ...layer,
                  keyframes: layer.keyframes.map((kf) => {
                    if (kf.frame !== frame) return kf;

                    return {
                      ...kf,
                      elements: [...kf.elements, shape],
                    };
                  }),
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  removeElement: (layerId, frame, elementId) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                return {
                  ...layer,
                  keyframes: layer.keyframes.map((kf) => {
                    if (kf.frame !== frame) return kf;

                    return {
                      ...kf,
                      elements: kf.elements.filter((el) => el.id !== elementId),
                    };
                  }),
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  addBitmapElement: (layerId, frame, assetId, x, y) => {
    set((state) => {
      const compositionId = state.project.activeCompositionId;
      const comp = state.project.compositions[compositionId];
      if (!comp) return state;

      const bitmapElement = {
        id: generateId("element"),
        type: "bitmap" as const,
        assetId,
        x,
        y,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        opacity: 1,
      };

      return {
        project: {
          ...state.project,
          compositions: {
            ...state.project.compositions,
            [compositionId]: {
              ...comp,
              layers: comp.layers.map((layer) => {
                if (layer.id !== layerId) return layer;

                return {
                  ...layer,
                  keyframes: layer.keyframes.map((kf) => {
                    if (kf.frame !== frame) return kf;

                    return {
                      ...kf,
                      elements: [...kf.elements, bitmapElement],
                    };
                  }),
                };
              }),
            },
          },
          meta: {
            ...state.project.meta,
            modifiedAt: new Date().toISOString(),
          },
        },
      };
    });
  },

  // ======================
  // アセット・シンボル
  // ======================
  addAsset: (assetData) => {
    const id = generateId("asset");
    set((state) => ({
      project: {
        ...state.project,
        assets: {
          ...state.project.assets,
          [id]: { ...assetData, id },
        },
        meta: {
          ...state.project.meta,
          modifiedAt: new Date().toISOString(),
        },
      },
    }));
    return id;
  },

  addSymbol: (symbolData) => {
    const id = generateId("sym");
    set((state) => ({
      project: {
        ...state.project,
        symbols: {
          ...state.project.symbols,
          [id]: { ...symbolData, id },
        },
        meta: {
          ...state.project.meta,
          modifiedAt: new Date().toISOString(),
        },
      },
    }));
    return id;
  },
}));
