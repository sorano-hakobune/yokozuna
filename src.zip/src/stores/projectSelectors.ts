import { useProjectStore } from "./projectStore";
import type {
  Composition,
  Layer,
  ProjectSettings,
  Asset,
  Symbol,
} from "@/types/project";

// ==============================
// 基本セレクター
// ==============================

/** プロジェクト全体 */
export const useProject = () => useProjectStore((s) => s.project);

/** メタ情報 */
export const useProjectMeta = () => useProjectStore((s) => s.project.meta);

/** ステージ設定 */
export const useProjectSettings = (): ProjectSettings =>
  useProjectStore((s) => s.project.settings);

/** 現在アクティブなコンポジションID */
export const useActiveCompositionId = () =>
  useProjectStore((s) => s.project.activeCompositionId);

// ==============================
// コンポジション関連
// ==============================

/** 現在アクティブなコンポジション本体 */
export const useActiveComposition = (): Composition | null =>
  useProjectStore((s) => {
    const id = s.project.activeCompositionId;
    return s.project.compositions[id] ?? null;
  });

/** すべてのコンポジション一覧（配列） */
export const useCompositions = () =>
  useProjectStore((s) => Object.values(s.project.compositions));

/** 特定のコンポジションを取得 */
export const useComposition = (compositionId: string) =>
  useProjectStore((s) => s.project.compositions[compositionId] ?? null);

// ==============================
// レイヤー関連
// ==============================

/** アクティブなコンポジションのレイヤー一覧 */
export const useActiveLayers = (): Layer[] =>
  useProjectStore((s) => {
    const comp = s.project.compositions[s.project.activeCompositionId];
    return comp?.layers ?? [];
  });

/** 特定レイヤーを取得 */
export const useLayer = (compositionId: string, layerId: string) =>
  useProjectStore((s) => {
    const comp = s.project.compositions[compositionId];
    return comp?.layers.find((l) => l.id === layerId) ?? null;
  });

// ==============================
// アセット・シンボル
// ==============================

/** すべてのアセット */
export const useAssets = (): Asset[] =>
  useProjectStore((s) => Object.values(s.project.assets));

/** すべてのシンボル */
export const useSymbols = (): Symbol[] =>
  useProjectStore((s) => Object.values(s.project.symbols));

/** 特定アセット */
export const useAsset = (assetId: string) =>
  useProjectStore((s) => s.project.assets[assetId] ?? null);

/** 特定シンボル */
export const useSymbol = (symbolId: string) =>
  useProjectStore((s) => s.project.symbols[symbolId] ?? null);

// ==============================
// 便利系
// ==============================

/** 現在のフレームレート */
export const useFps = () => useProjectStore((s) => s.project.settings.fps);

/** ステージサイズ */
export const useStageSize = () =>
  useProjectStore((s) => ({
    width: s.project.settings.width,
    height: s.project.settings.height,
  }));
