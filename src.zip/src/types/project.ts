// ==============================
// 基本型
// ==============================

/** イージング種類（最初は文字列でシンプルに） */
export type EasingType =
  | "linear"
  | "easeIn"
  | "easeOut"
  | "easeInOut";

/** トゥイーン種類 */
export type TweenType = "none" | "motion" | "shape";

/** レイヤー種類 */
export type LayerType = "normal" | "mask" | "guide";

/** シンボル種類 */
export type SymbolType = "graphic" | "movieClip";

/** 要素種類 */
export type ElementType = "instance" | "bitmap" | "shape";

/** シェイプの種類 */
export type ShapeType = "rectangle" | "circle" | "line" | "path";

/** アセット種類 */
export type AssetType = "image" | "audio" | "svg";

// ==============================
// 共通
// ==============================

export interface Pivot {
  x: number;
  y: number;
}

export interface Transform {
  x: number;
  y: number;
  scaleX: number;
  scaleY: number;
  rotation: number; // degree
  opacity: number; // 0 ~ 1
  pivot?: Pivot;
}

// ==============================
// 要素（Element）
// ==============================

export interface BaseElement extends Transform {
  id: string;
  type: ElementType;
  name?: string;
}

/** シンボルのインスタンス */
export interface InstanceElement extends BaseElement {
  type: "instance";
  symbolId: string;
}

/** 画像を直接配置 */
export interface BitmapElement extends BaseElement {
  type: "bitmap";
  assetId: string;
}

/** 図形用 */
export interface ShapeElement extends BaseElement {
  type: "shape";
  shapeType: ShapeType;
  
  // 図形固有のプロパティ
  fill?: string; // 塗りつぶし色 (CSS色文字列)
  stroke?: string; // 線の色 (CSS色文字列)
  strokeWidth?: number; // 線の太さ
  
  // 図形のパラメータ
  width?: number; // 矩形の幅
  height?: number; // 矩形の高さ
  radius?: number; // 円の半径
  points?: { x: number; y: number }[]; // 線やパスのポイント
  closePath?: boolean; // パスを閉じるかどうか
}

export type Element = InstanceElement | BitmapElement | ShapeElement;

// ==============================
// キーフレーム
// ==============================

export interface Keyframe {
  /** このキーフレームが存在するフレーム番号（0始まり） */
  frame: number;

  /** 次のキーフレームまでのトゥイーン */
  tween: TweenType;

  /** トゥイーン時のイージング */
  easing?: EasingType;

  /** このキーフレーム上の要素一覧 */
  elements: Element[];
}

// ==============================
// レイヤー
// ==============================

export interface Layer {
  id: string;
  name: string;
  type: LayerType;
  visible: boolean;
  locked: boolean;

  /** フレーム番号順にソートされている前提 */
  keyframes: Keyframe[];
}

// ==============================
// アセット
// ==============================

export interface Asset {
  id: string;
  type: AssetType;
  name: string;
  src: string; // 相対パス or base64
  width?: number;
  height?: number;
  mimeType?: string;
  duration?: number; // 音声用（秒 or フレーム）
}

// ==============================
// シンボル
// ==============================

export interface Symbol {
  id: string;
  name: string;
  type: SymbolType;
  width: number;
  height: number;
  pivot: Pivot;
  duration: number; // シンボル自身の長さ（フレーム）
  layers: Layer[];
}

// ==============================
// コンポジション（タイムライン）
// ==============================

export interface Composition {
  id: string;
  name: string;
  duration: number; // このコンポジションの長さ（フレーム）
  layers: Layer[];
}

// ==============================
// プロジェクト全体
// ==============================

export interface ProjectMeta {
  name: string;
  createdAt: string; // ISO 8601
  modifiedAt: string;
  author?: string;
}

export interface ProjectSettings {
  width: number;
  height: number;
  fps: number;
  backgroundColor: string;
  duration: number; // プロジェクト全体の長さ（フレーム）
}

export interface Project {
  version: string; // 例: "1.0.0"
  meta: ProjectMeta;
  settings: ProjectSettings;

  /** id → Asset */
  assets: Record<string, Asset>;

  /** id → Symbol */
  symbols: Record<string, Symbol>;

  /** id → Composition */
  compositions: Record<string, Composition>;

  /** 現在編集中のコンポジションID */
  activeCompositionId: string;

  /** 互換性のためのプロパティ（実際はcompositionsから取得） */
  layers?: Layer[];
  width?: number;
  height?: number;
  fps?: number;
}
