import React, { useEffect } from "react";
import { Toolbar } from "./components/Toolbar";
import { Timeline } from "./components/Timeline";
import { Stage } from "./components/Stage";
import { Inspector } from "./components/Inspector";
import { PlaybackControls } from "./components/Playback";
import { useProjectStore } from "./stores/projectStore";
import "./components/Timeline/timeline.css";

export const App: React.FC = () => {
  const selectedTool = useProjectStore((state) => state.selectedTool);
  const setSelectedTool = useProjectStore((state) => (state as any).setSelectedTool);
  const selectedLayerId = useProjectStore((state) => state.selectedLayerId);
  const selectedElementId = useProjectStore((state) => state.selectedElementId);
  const currentFrame = useProjectStore((state) => state.currentFrame);
  const copyElement = useProjectStore((state) => (state as any).copyElement);
  const pasteElement = useProjectStore((state) => (state as any).pasteElement);
  const removeElement = useProjectStore((state) => (state as any).removeElement);

  // キーボードショートカット
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+C / Cmd+C: コピー
      if ((e.ctrlKey || e.metaKey) && e.key === "c") {
        if (selectedLayerId && selectedElementId) {
          copyElement(selectedLayerId, currentFrame, selectedElementId);
          e.preventDefault();
        }
      }
      
      // Ctrl+V / Cmd+V: ペースト
      if ((e.ctrlKey || e.metaKey) && e.key === "v") {
        if (selectedLayerId) {
          pasteElement(selectedLayerId, currentFrame);
          e.preventDefault();
        }
      }
      
      // Delete / Backspace: 削除
      if ((e.key === "Delete" || e.key === "Backspace") && selectedElementId) {
        if (selectedLayerId) {
          removeElement(selectedLayerId, currentFrame, selectedElementId);
          e.preventDefault();
        }
      }
      
      // V: 選択ツール
      if (e.key === "v" && !e.ctrlKey && !e.metaKey) {
        setSelectedTool("select");
      }
      
      // R: 矩形ツール
      if (e.key === "r" && !e.ctrlKey && !e.metaKey) {
        setSelectedTool("rectangle");
      }
      
      // C: 円ツール
      if (e.key === "c" && !e.ctrlKey && !e.metaKey) {
        setSelectedTool("circle");
      }
      
      // L: 線ツール
      if (e.key === "l" && !e.ctrlKey && !e.metaKey) {
        setSelectedTool("line");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedTool, selectedLayerId, selectedElementId, currentFrame, copyElement, pasteElement, removeElement, setSelectedTool]);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        width: "100vw",
        backgroundColor: "#18181b",
      }}
    >
      {/* 画面上部：ツールバー（Save/Load） */}
      <Toolbar />

      {/* メイン編集エリア */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        <Stage />
        <Inspector />
      </div>

      {/* 下部エリア：プレイヤーとタイムライン */}
      <PlaybackControls />
      <Timeline />
    </div>
  );
};

export default App;
