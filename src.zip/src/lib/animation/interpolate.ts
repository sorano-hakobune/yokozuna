export interface KeyframeData {
  frame: number;
  x?: number;
  y?: number;
  opacity?: number;
  scaleX?: number;
  scaleY?: number;
  rotation?: number;
  [key: string]: any;
}

/**
 * 2つの数値間を線形補間 (Lerp)
 */
export const lerp = (start: number, end: number, t: number): number => {
  return start + (end - start) * t;
};

/**
 * 現在のフレームにおける補間されたキーフレーム値を算出
 */
export const getInterpolatedFrame = (
  keyframes: KeyframeData[],
  currentFrame: number,
): KeyframeData | null => {
  if (!keyframes || keyframes.length === 0) return null;

  // 昇順ソート
  const sorted = [...keyframes].sort((a, b) => a.frame - b.frame);

  // 最初のキーフレームより前
  if (currentFrame <= sorted[0].frame) {
    return sorted[0];
  }

  // 最後のキーフレームより後
  if (currentFrame >= sorted[sorted.length - 1].frame) {
    return sorted[sorted.length - 1];
  }

  // 前後のキーフレームを探す
  let prevFrame = sorted[0];
  let nextFrame = sorted[sorted.length - 1];

  for (let i = 0; i < sorted.length - 1; i++) {
    if (
      currentFrame >= sorted[i].frame &&
      currentFrame <= sorted[i + 1].frame
    ) {
      prevFrame = sorted[i];
      nextFrame = sorted[i + 1];
      break;
    }
  }

  // 同一フレームの場合はそのまま返す
  if (prevFrame.frame === nextFrame.frame) {
    return prevFrame;
  }

  // 進行度 t (0.0 ～ 1.0)
  const t =
    (currentFrame - prevFrame.frame) / (nextFrame.frame - prevFrame.frame);

  // 各プロパティの補間
  return {
    frame: currentFrame,
    x: lerp(prevFrame.x ?? 0, nextFrame.x ?? 0, t),
    y: lerp(prevFrame.y ?? 0, nextFrame.y ?? 0, t),
    opacity: lerp(prevFrame.opacity ?? 1, nextFrame.opacity ?? 1, t),
    scaleX: lerp(prevFrame.scaleX ?? 1, nextFrame.scaleX ?? 1, t),
    scaleY: lerp(prevFrame.scaleY ?? 1, nextFrame.scaleY ?? 1, t),
    rotation: lerp(prevFrame.rotation ?? 0, nextFrame.rotation ?? 0, t),
  };
};
