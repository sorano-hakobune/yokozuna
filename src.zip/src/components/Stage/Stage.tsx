import React, { useRef, useEffect, useState } from "react";
import { useProjectStore } from "../../stores/projectStore";
import {
  getInterpolatedFrame,
  KeyframeData,
} from "../../lib/animation/interpolate";
import { drawShape, createRectangleShape, createCircleShape, createLineShape } from "../../lib/draw";
import type { ShapeElement } from "../../types/project";

export const Stage: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isPanning, setIsPanning] = useState(false);
  const dragStartRef = useRef<{
    x: number;
    y: number;
    initialObjX: number;
    initialObjY: number;
  } | null>(null);
  const drawStartRef = useRef<{
    x: number;
    y: number;
  } | null>(null);
  const panStartRef = useRef<{
    x: number;
    y: number;
  } | null>(null);

  const project = useProjectStore((state) => state.project);
  const currentFrame = useProjectStore((state) => state.currentFrame);
  const selectedLayerId = useProjectStore((state) => state.selectedLayerId);
  const updateKeyframe = useProjectStore(
    (state) => (state as any).updateKeyframe,
  );
  const selectedTool = useProjectStore((state) => state.selectedTool);
  const addShapeToLayer = useProjectStore(
    (state) => (state as any).addShapeToLayer,
  );
  const setSelectedElementId = useProjectStore(
    (state) => (state as any).setSelectedElementId,
  );
  const canvasZoom = useProjectStore((state) => (state as any).canvasZoom);
  const canvasPan = useProjectStore((state) => (state as any).canvasPan);
  const setCanvasZoom = useProjectStore((state) => (state as any).setCanvasZoom);
  const setCanvasPan = useProjectStore((state) => (state as any).setCanvasPan);

  // レイヤー一覧の安全な取得
  const getLayersArray = (): any[] => {
    if (!project) return [];
    if (Array.isArray(project.layers)) return project.layers;
    if ((project as any).layerIds && project.layers) {
      return (project as any).layerIds
        .map((id: string) => (project.layers as any)[id])
        .filter(Boolean);
    }
    if (project.layers && typeof project.layers === "object")
      return Object.values(project.layers);
    return [];
  };

  const layersArray = getLayersArray();
  const activeLayer =
    layersArray.find((l) => l.id === selectedLayerId) || layersArray[0];

  // 再描画ロジック
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !project) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // 1. キャンバスのクリア
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 2. ステージ背景（白）
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 3. レイヤー描画（背面から）
    const sortedLayers = [...layersArray].reverse();

    sortedLayers.forEach((layer) => {
      if (!layer || layer.visible === false) return;

      const keyframes: KeyframeData[] = Array.isArray(layer.keyframes)
        ? layer.keyframes
        : typeof layer.keyframes === "object"
          ? Object.values(layer.keyframes || {})
          : [];

      const interpolated = getInterpolatedFrame(keyframes, currentFrame);

      if (interpolated) {
        ctx.save();

        const x = interpolated.x ?? 0;
        const y = interpolated.y ?? 0;
        const opacity = interpolated.opacity ?? 1;
        const scaleX = interpolated.scaleX ?? 1;
        const scaleY = interpolated.scaleY ?? 1;
        const rotation = (interpolated.rotation ?? 0) * (Math.PI / 180);

        ctx.globalAlpha = opacity;
        ctx.translate(x, y);
        ctx.rotate(rotation);
        ctx.scale(scaleX, scaleY);

        // 描画要素（図形・画像）
        interpolated.elements?.forEach((element: any) => {
          if (element.type === "shape") {
            const shapeElement = element as ShapeElement;
            // 図形の独自の変換を適用
            ctx.save();
            ctx.translate(shapeElement.x ?? 0, shapeElement.y ?? 0);
            ctx.rotate((shapeElement.rotation ?? 0) * (Math.PI / 180));
            ctx.scale(shapeElement.scaleX ?? 1, shapeElement.scaleY ?? 1);
            ctx.globalAlpha = shapeElement.opacity ?? 1;
            
            // 図形の座標を中心に揃える
            const centeredShape = {
              ...shapeElement,
              x: 0,
              y: 0,
            };
            drawShape(ctx, centeredShape);
            ctx.restore();
          } else if (element.type === "bitmap") {
            const bitmapElement = element as any;
            const asset = project.assets[bitmapElement.assetId];
            
            if (asset && asset.src) {
              ctx.save();
              ctx.translate(bitmapElement.x ?? 0, bitmapElement.y ?? 0);
              ctx.rotate((bitmapElement.rotation ?? 0) * (Math.PI / 180));
              ctx.scale(bitmapElement.scaleX ?? 1, bitmapElement.scaleY ?? 1);
              ctx.globalAlpha = bitmapElement.opacity ?? 1;
              
              const img = new Image();
              img.src = asset.src;
              if (img.complete) {
                ctx.drawImage(img, -img.width / 2, -img.height / 2);
              }
              ctx.restore();
            }
          }
        });

        // 選択中のレイヤーであれば枠線（ギズモ）を描画
        if (activeLayer && layer.id === activeLayer.id) {
          ctx.strokeStyle = "#ef4444";
          ctx.lineWidth = 2 / Math.max(scaleX, scaleY);
          ctx.strokeRect(-52, -52, 104, 104);
        }

        ctx.restore();
      }
    });
  }, [project, currentFrame, selectedLayerId, activeLayer, layersArray]);

  // マウス座標をキャンバス内部解像度（例: 1920x1080）に変換
  const getCanvasCoordinates = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    // ズームとパンを考慮
    const x = ((e.clientX - rect.left) * scaleX - canvasPan.x) / canvasZoom;
    const y = ((e.clientY - rect.top) * scaleY - canvasPan.y) / canvasZoom;

    return { x, y };
  };

  // ホイールでのズーム
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    
    if (e.ctrlKey || e.metaKey) {
      // ズーム
      const delta = e.deltaY > 0 ? 0.9 : 1.1;
      const newZoom = Math.max(0.1, Math.min(5, canvasZoom * delta));
      setCanvasZoom(newZoom);
    } else {
      // パン
      setCanvasPan({
        x: canvasPan.x - e.deltaX,
        y: canvasPan.y - e.deltaY,
      });
    }
  };

  // ドラッグ開始
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getCanvasCoordinates(e);

    // 描画ツールが選択されている場合
    if (selectedTool !== "select") {
      if (!activeLayer || !addShapeToLayer) return;
      
      setIsDrawing(true);
      drawStartRef.current = {
        x: coords.x,
        y: coords.y,
      };
      return;
    }

    // 選択ツールの場合は図形選択またはドラッグ処理
    if (!activeLayer) return;

    const keyframes = Array.isArray(activeLayer.keyframes)
      ? activeLayer.keyframes
      : Object.values(activeLayer.keyframes || {});
    const interpolated = getInterpolatedFrame(keyframes, currentFrame);

    // 図形のヒットテスト
    if (interpolated?.elements) {
      for (const element of interpolated.elements) {
        if (element.type === "shape") {
          const shape = element as ShapeElement;
          if (isPointInShape(coords.x, coords.y, shape, interpolated)) {
            setSelectedElementId(element.id);
            return;
          }
        }
      }
    }

    // 図形が選択されなかった場合は選択解除
    setSelectedElementId(undefined);

    // 既存のドラッグ処理
    const currentX = interpolated?.x ?? 0;
    const currentY = interpolated?.y ?? 0;

    setIsDragging(true);
    dragStartRef.current = {
      x: coords.x,
      y: coords.y,
      initialObjX: currentX,
      initialObjY: currentY,
    };
  };

  // 図形のヒットテスト
  const isPointInShape = (
    px: number,
    py: number,
    shape: ShapeElement,
    interpolated: any
  ): boolean => {
    const layerX = interpolated.x ?? 0;
    const layerY = interpolated.y ?? 0;
    const shapeX = shape.x ?? 0;
    const shapeY = shape.y ?? 0;
    const scaleX = interpolated.scaleX ?? 1;
    const scaleY = interpolated.scaleY ?? 1;

    const globalX = layerX + shapeX * scaleX;
    const globalY = layerY + shapeY * scaleY;

    switch (shape.shapeType) {
      case "rectangle":
        const width = (shape.width ?? 100) * scaleX;
        const height = (shape.height ?? 100) * scaleY;
        return (
          px >= globalX - width / 2 &&
          px <= globalX + width / 2 &&
          py >= globalY - height / 2 &&
          py <= globalY + height / 2
        );
      case "circle":
        const radius = (shape.radius ?? 50) * Math.max(scaleX, scaleY);
        const distance = Math.sqrt(Math.pow(px - globalX, 2) + Math.pow(py - globalY, 2));
        return distance <= radius;
      case "line":
        if (!shape.points || shape.points.length < 2) return false;
        const start = shape.points[0];
        const end = shape.points[1];
        const lineStartX = globalX + start.x * scaleX;
        const lineStartY = globalY + start.y * scaleY;
        const lineEndX = globalX + end.x * scaleX;
        const lineEndY = globalY + end.y * scaleY;
        const strokeWidth = (shape.strokeWidth ?? 2) * Math.max(scaleX, scaleY);
        return isPointNearLine(px, py, lineStartX, lineStartY, lineEndX, lineEndY, strokeWidth);
      default:
        return false;
    }
  };

  // 線と点の距離計算
  const isPointNearLine = (
    px: number,
    py: number,
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    tolerance: number
  ): boolean => {
    const A = px - x1;
    const B = py - y1;
    const C = x2 - x1;
    const D = y2 - y1;

    const dot = A * C + B * D;
    const lenSq = C * C + D * D;
    let param = -1;
    if (lenSq !== 0) param = dot / lenSq;

    let xx, yy;

    if (param < 0) {
      xx = x1;
      yy = y1;
    } else if (param > 1) {
      xx = x2;
      yy = y2;
    } else {
      xx = x1 + param * C;
      yy = y1 + param * D;
    }

    const dx = px - xx;
    const dy = py - yy;
    const distance = Math.sqrt(dx * dx + dy * dy);

    return distance <= tolerance;
  };

  // ドラッグ中（X / Y座標のリアルタイム更新）
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !dragStartRef.current || !activeLayer || !updateKeyframe)
      return;

    const coords = getCanvasCoordinates(e);
    const deltaX = coords.x - dragStartRef.current.x;
    const deltaY = coords.y - dragStartRef.current.y;

    const newX = Math.round(dragStartRef.current.initialObjX + deltaX);
    const newY = Math.round(dragStartRef.current.initialObjY + deltaY);

    updateKeyframe(activeLayer.id, currentFrame, { x: newX, y: newY });
  };

  // ドラッグ終了
  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    // 描画終了処理
    if (isDrawing && drawStartRef.current && activeLayer && addShapeToLayer) {
      const coords = getCanvasCoordinates(e);
      const startX = drawStartRef.current.x;
      const startY = drawStartRef.current.y;
      const endX = coords.x;
      const endY = coords.y;

      let newShape: ShapeElement;

      switch (selectedTool) {
        case "rectangle":
          const width = Math.abs(endX - startX);
          const height = Math.abs(endY - startY);
          const centerX = (startX + endX) / 2;
          const centerY = (startY + endY) / 2;
          newShape = createRectangleShape(centerX, centerY, width, height);
          break;
        case "circle":
          const radius = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
          newShape = createCircleShape(startX, startY, radius);
          break;
        case "line":
          newShape = createLineShape(startX, startY, endX, endY);
          break;
        default:
          newShape = createRectangleShape(startX, startY, 100, 100);
      }

      addShapeToLayer(activeLayer.id, currentFrame, newShape);
      setIsDrawing(false);
      drawStartRef.current = null;
    }

    // ドラッグ終了処理
    setIsDragging(false);
    dragStartRef.current = null;
  };

  return (
    <div
      className="stage-container"
      style={{
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#18181b",
        overflow: "hidden",
        position: "relative",
        padding: "20px",
      }}
    >
      <canvas
        ref={canvasRef}
        width={project?.width || 1920}
        height={project?.height || 1080}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={(e) => handleMouseUp(e)}
        style={{
          maxWidth: "100%",
          maxHeight: "100%",
          objectFit: "contain",
          boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.5)",
          backgroundColor: "#ffffff",
          cursor: isDragging ? "grabbing" : "grab",
        }}
      />
    </div>
  );
};
