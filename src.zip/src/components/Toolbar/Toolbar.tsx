import React from "react";
import { save, open } from "@tauri-apps/plugin-dialog";
import { writeTextFile, readTextFile } from "@tauri-apps/plugin-fs";
import { useProjectStore } from "../../stores/projectStore";

export const Toolbar: React.FC = () => {
  const project = useProjectStore((state) => state.project);
  const setProject = useProjectStore((state) => (state as any).setProject);
  const selectedTool = useProjectStore((state) => (state as any).selectedTool);
  const setSelectedTool = useProjectStore((state) => (state as any).setSelectedTool);
  const addAsset = useProjectStore((state) => (state as any).addAsset);
  const addBitmapElement = useProjectStore((state) => (state as any).addBitmapElement);
  const selectedLayerId = useProjectStore((state) => state.selectedLayerId);
  const currentFrame = useProjectStore((state) => state.currentFrame);

  // プロジェクトの保存
  const handleSave = async () => {
    if (!project) return;
    try {
      const filePath = await save({
        title: "プロジェクトを保存",
        filters: [{ name: "Project File", extensions: ["json"] }],
      });

      if (filePath) {
        const projectData = JSON.stringify(project, null, 2);
        await writeTextFile(filePath, projectData);
      }
    } catch (error) {
      console.error("保存エラー:", error);
    }
  };

  // プロジェクトの読み込み
  const handleOpen = async () => {
    try {
      const filePath = await open({
        title: "プロジェクトを開く",
        filters: [{ name: "Project File", extensions: ["json"] }],
        multiple: false,
        directory: false,
      });

      if (filePath && typeof filePath === "string") {
        const fileContent = await readTextFile(filePath);
        const parsedData = JSON.parse(fileContent);
        if (setProject) {
          setProject(parsedData);
        }
      }
    } catch (error) {
      console.error("読み込みエラー:", error);
    }
  };

  // 画像インポート
  const handleImportImage = async () => {
    try {
      const filePath = await open({
        title: "画像をインポート",
        filters: [
          { name: "Images", extensions: ["png", "jpg", "jpeg", "gif", "webp"] },
          { name: "All Files", extensions: ["*"] },
        ],
        multiple: false,
        directory: false,
      });

      if (filePath && typeof filePath === "string") {
        // ファイルパスをそのまま使用（Tauriではfile://プロトコルでアクセス可能）
        const fileName = filePath.split("\\").pop() || "image";
        const extension = fileName.split(".").pop() || "png";
        const mimeType = `image/${extension}`;

        const assetId = addAsset({
          type: "image",
          name: fileName,
          src: `file://${filePath}`,
          mimeType,
        });

        if (selectedLayerId && addBitmapElement) {
          addBitmapElement(selectedLayerId, currentFrame, assetId, 960, 540);
        }
      }
    } catch (error) {
      console.error("画像インポートエラー:", error);
    }
  };

  // SVGインポート
  const handleImportSVG = async () => {
    try {
      const filePath = await open({
        title: "SVGをインポート",
        filters: [{ name: "SVG", extensions: ["svg"] }],
        multiple: false,
        directory: false,
      });

      if (filePath && typeof filePath === "string") {
        const fileContent = await readTextFile(filePath);
        const fileName = filePath.split("\\").pop() || "image.svg";

        const assetId = addAsset({
          type: "svg",
          name: fileName,
          src: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(fileContent)}`,
          mimeType: "image/svg+xml",
        });

        if (selectedLayerId && addBitmapElement) {
          addBitmapElement(selectedLayerId, currentFrame, assetId, 960, 540);
        }
      }
    } catch (error) {
      console.error("SVGインポートエラー:", error);
    }
  };

  // PSDインポート（フラット画像として）
  const handleImportPSD = async () => {
    try {
      const filePath = await open({
        title: "PSDをインポート",
        filters: [{ name: "Photoshop", extensions: ["psd", "psb"] }],
        multiple: false,
        directory: false,
      });

      if (filePath && typeof filePath === "string") {
        const fileName = filePath.split("\\").pop() || "image.psd";

        const assetId = addAsset({
          type: "image",
          name: fileName,
          src: `file://${filePath}`,
          mimeType: "image/psd",
        });

        if (selectedLayerId && addBitmapElement) {
          addBitmapElement(selectedLayerId, currentFrame, assetId, 960, 540);
        }
      }
    } catch (error) {
      console.error("PSDインポートエラー:", error);
    }
  };

  return (
    <header style={headerStyle}>
      <div style={logoStyle}>Tauri Animator</div>
      <div style={menuStyle}>
        <button 
          style={selectedTool === "select" ? activeButtonStyle : buttonStyle} 
          onClick={() => setSelectedTool("select")}
        >
          ↖ 選択
        </button>
        <button 
          style={selectedTool === "rectangle" ? activeButtonStyle : buttonStyle} 
          onClick={() => setSelectedTool("rectangle")}
        >
          ▢ 矩形
        </button>
        <button 
          style={selectedTool === "circle" ? activeButtonStyle : buttonStyle} 
          onClick={() => setSelectedTool("circle")}
        >
          ○ 円
        </button>
        <button 
          style={selectedTool === "line" ? activeButtonStyle : buttonStyle} 
          onClick={() => setSelectedTool("line")}
        >
          / 線
        </button>
        <div style={dividerStyle} />
        <button style={buttonStyle} onClick={handleOpen}>
          📁 開く
        </button>
        <button style={buttonStyle} onClick={handleSave}>
          💾 保存
        </button>
        <div style={dividerStyle} />
        <button style={buttonStyle} onClick={handleImportImage}>
          🖼️ 画像
        </button>
        <button style={buttonStyle} onClick={handleImportSVG}>
          📐 SVG
        </button>
        <button style={buttonStyle} onClick={handleImportPSD}>
          🎨 PSD
        </button>
      </div>
    </header>
  );
};

// スタイル定義
const headerStyle: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  padding: "8px 16px",
  backgroundColor: "#18181b",
  borderBottom: "1px solid #27272a",
  color: "#f4f4f5",
  userSelect: "none",
};

const logoStyle: React.CSSProperties = {
  fontWeight: "bold",
  fontSize: "14px",
  letterSpacing: "1px",
};

const menuStyle: React.CSSProperties = {
  display: "flex",
  gap: "8px",
};

const buttonStyle: React.CSSProperties = {
  backgroundColor: "#27272a",
  border: "1px solid #3f3f46",
  color: "#ffffff",
  borderRadius: "4px",
  padding: "6px 12px",
  cursor: "pointer",
  fontSize: "12px",
  display: "flex",
  alignItems: "center",
  gap: "6px",
  transition: "background-color 0.2s",
};

const activeButtonStyle: React.CSSProperties = {
  ...buttonStyle,
  backgroundColor: "#3b82f6",
  borderColor: "#2563eb",
};

const dividerStyle: React.CSSProperties = {
  width: "1px",
  height: "24px",
  backgroundColor: "#3f3f46",
  margin: "0 4px",
};
