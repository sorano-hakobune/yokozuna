import React from "react";
import { useProjectStore } from "@/stores/projectStore";
import { getInterpolatedFrame } from "@/lib/animation/interpolate";
import type { ShapeElement } from "@/types/project";

export const Inspector: React.FC = () => {
  const project = useProjectStore((state) => state.project);
  const currentFrame = useProjectStore((state) => state.currentFrame);
  const selectedLayerId = useProjectStore((state) => state.selectedLayerId);
  const selectedElementId = useProjectStore((state) => state.selectedElementId);
  const updateKeyframe = useProjectStore(
    (state) => (state as any).updateKeyframe,
  );
  const updateLayer = useProjectStore((state) => (state as any).updateLayer);
  const updateElement = useProjectStore((state) => (state as any).updateElement);
  const removeElement = useProjectStore((state) => (state as any).removeElement);

  if (!project) return null;

  // レイヤー一覧の安全な取得
  let layersArray: any[] = [];
  if (Array.isArray(project.layers)) {
    layersArray = project.layers;
  } else if ((project as any).layerIds && project.layers) {
    layersArray = (project as any).layerIds
      .map((id: string) => (project.layers as any)[id])
      .filter(Boolean);
  } else if (project.layers && typeof project.layers === "object") {
    layersArray = Object.values(project.layers);
  }

  // 選択中のレイヤー（未選択の場合は最初のレイヤー）
  const activeLayer =
    layersArray.find((l) => l.id === selectedLayerId) || layersArray[0];

  if (!activeLayer) {
    return (
      <aside style={panelStyle}>
        <div style={headerStyle}>Inspector</div>
        <div style={{ padding: "16px", color: "#71717a", fontSize: "12px" }}>
          レイヤーが選択されていません
        </div>
      </aside>
    );
  }

  const keyframes = Array.isArray(activeLayer.keyframes)
    ? activeLayer.keyframes
    : typeof activeLayer.keyframes === "object"
      ? Object.values(activeLayer.keyframes || {})
      : [];

  const interpolated = getInterpolatedFrame(keyframes, currentFrame) || {
    x: 0,
    y: 0,
    scaleX: 1,
    scaleY: 1,
    rotation: 0,
    opacity: 1,
    elements: [],
  };

  // 選択中の要素を取得
  const selectedElement = (interpolated.elements || []).find(
    (el: any) => el.id === selectedElementId
  ) as ShapeElement | undefined;

  // プロパティ更新ハンドラー
  const handlePropertyChange = (key: string, value: number | string) => {
    if (updateKeyframe) {
      updateKeyframe(activeLayer.id, currentFrame, { [key]: value });
    }
  };

  // 要素プロパティ更新ハンドラー
  const handleElementPropertyChange = (key: string, value: number | string) => {
    if (selectedElementId && updateElement) {
      updateElement(activeLayer.id, currentFrame, selectedElementId, { [key]: value });
    }
  };

  // 要素削除ハンドラー
  const handleDeleteElement = () => {
    if (selectedElementId && removeElement) {
      removeElement(activeLayer.id, currentFrame, selectedElementId);
    }
  };

  return (
    <aside style={panelStyle}>
      <div style={headerStyle}>Inspector</div>

      <div
        style={{
          padding: "12px 16px",
          display: "flex",
          flexDirection: "column",
          gap: "16px",
        }}
      >
        {/* レイヤー情報 */}
        <section>
          <div style={sectionTitleStyle}>Layer Info</div>
          <div style={fieldStyle}>
            <label style={labelStyle}>Name</label>
            <input
              type="text"
              value={activeLayer.name || ""}
              onChange={(e) =>
                updateLayer &&
                updateLayer(activeLayer.id, { name: e.target.value })
              }
              style={inputTextStyle}
            />
          </div>
        </section>

        {/* Transform プロパティ */}
        <section>
          <div style={sectionTitleStyle}>Transform (Frame: {currentFrame})</div>

          <div style={gridStyle}>
            <div style={fieldStyle}>
              <label style={labelStyle}>X</label>
              <input
                type="number"
                value={Math.round(interpolated.x ?? 0)}
                onChange={(e) =>
                  handlePropertyChange("x", Number(e.target.value))
                }
                style={inputStyle}
              />
            </div>
            <div style={fieldStyle}>
              <label style={labelStyle}>Y</label>
              <input
                type="number"
                value={Math.round(interpolated.y ?? 0)}
                onChange={(e) =>
                  handlePropertyChange("y", Number(e.target.value))
                }
                style={inputStyle}
              />
            </div>
          </div>

          <div style={{ ...gridStyle, marginTop: "8px" }}>
            <div style={fieldStyle}>
              <label style={labelStyle}>Scale X</label>
              <input
                type="number"
                step="0.1"
                value={interpolated.scaleX ?? 1}
                onChange={(e) =>
                  handlePropertyChange("scaleX", Number(e.target.value))
                }
                style={inputStyle}
              />
            </div>
            <div style={fieldStyle}>
              <label style={labelStyle}>Scale Y</label>
              <input
                type="number"
                step="0.1"
                value={interpolated.scaleY ?? 1}
                onChange={(e) =>
                  handlePropertyChange("scaleY", Number(e.target.value))
                }
                style={inputStyle}
              />
            </div>
          </div>

          <div style={{ ...gridStyle, marginTop: "8px" }}>
            <div style={fieldStyle}>
              <label style={labelStyle}>Rotation (°)</label>
              <input
                type="number"
                value={Math.round(interpolated.rotation ?? 0)}
                onChange={(e) =>
                  handlePropertyChange("rotation", Number(e.target.value))
                }
                style={inputStyle}
              />
            </div>
            <div style={fieldStyle}>
              <label style={labelStyle}>Opacity</label>
              <input
                type="number"
                min="0"
                max="1"
                step="0.05"
                value={interpolated.opacity ?? 1}
                onChange={(e) =>
                  handlePropertyChange("opacity", Number(e.target.value))
                }
                style={inputStyle}
              />
            </div>
          </div>
        </section>

        {/* 要素プロパティ（選択中の要素がある場合） */}
        {selectedElement && selectedElement.type === "shape" && (
          <section>
            <div style={sectionTitleStyle}>Shape Properties</div>
            
            <div style={fieldStyle}>
              <label style={labelStyle}>Type</label>
              <div style={inputStyle}>{selectedElement.shapeType}</div>
            </div>

            {/* 要素のTransformプロパティ */}
            <div style={{ ...gridStyle, marginTop: "8px" }}>
              <div style={fieldStyle}>
                <label style={labelStyle}>X</label>
                <input
                  type="number"
                  value={Math.round(selectedElement.x ?? 0)}
                  onChange={(e) =>
                    handleElementPropertyChange("x", Number(e.target.value))
                  }
                  style={inputStyle}
                />
              </div>
              <div style={fieldStyle}>
                <label style={labelStyle}>Y</label>
                <input
                  type="number"
                  value={Math.round(selectedElement.y ?? 0)}
                  onChange={(e) =>
                    handleElementPropertyChange("y", Number(e.target.value))
                  }
                  style={inputStyle}
                />
              </div>
            </div>

            {selectedElement.shapeType === "rectangle" && (
              <div style={{ ...gridStyle, marginTop: "8px" }}>
                <div style={fieldStyle}>
                  <label style={labelStyle}>Width</label>
                  <input
                    type="number"
                    value={selectedElement.width ?? 100}
                    onChange={(e) =>
                      handleElementPropertyChange("width", Number(e.target.value))
                    }
                    style={inputStyle}
                  />
                </div>
                <div style={fieldStyle}>
                  <label style={labelStyle}>Height</label>
                  <input
                    type="number"
                    value={selectedElement.height ?? 100}
                    onChange={(e) =>
                      handleElementPropertyChange("height", Number(e.target.value))
                    }
                    style={inputStyle}
                  />
                </div>
              </div>
            )}

            {selectedElement.shapeType === "circle" && (
              <div style={{ ...gridStyle, marginTop: "8px" }}>
                <div style={fieldStyle}>
                  <label style={labelStyle}>Radius</label>
                  <input
                    type="number"
                    value={selectedElement.radius ?? 50}
                    onChange={(e) =>
                      handleElementPropertyChange("radius", Number(e.target.value))
                    }
                    style={inputStyle}
                  />
                </div>
              </div>
            )}

            <div style={{ ...gridStyle, marginTop: "8px" }}>
              <div style={fieldStyle}>
                <label style={labelStyle}>Fill</label>
                <input
                  type="color"
                  value={selectedElement.fill ?? "#3b82f6"}
                  onChange={(e) =>
                    handleElementPropertyChange("fill", e.target.value)
                  }
                  style={{ ...inputStyle, height: "30px", padding: "2px" }}
                />
              </div>
              <div style={fieldStyle}>
                <label style={labelStyle}>Stroke</label>
                <input
                  type="color"
                  value={selectedElement.stroke ?? "#1d4ed8"}
                  onChange={(e) =>
                    handleElementPropertyChange("stroke", e.target.value)
                  }
                  style={{ ...inputStyle, height: "30px", padding: "2px" }}
                />
              </div>
            </div>

            <div style={{ ...gridStyle, marginTop: "8px" }}>
              <div style={fieldStyle}>
                <label style={labelStyle}>Stroke Width</label>
                <input
                  type="number"
                  min="0"
                  value={selectedElement.strokeWidth ?? 2}
                  onChange={(e) =>
                    handleElementPropertyChange("strokeWidth", Number(e.target.value))
                  }
                  style={inputStyle}
                />
              </div>
            </div>

            <div style={{ marginTop: "16px" }}>
              <button
                onClick={handleDeleteElement}
                style={{
                  ...inputStyle,
                  backgroundColor: "#ef4444",
                  borderColor: "#dc2626",
                  cursor: "pointer",
                  color: "#ffffff",
                  padding: "8px 16px",
                }}
              >
                Delete Shape
              </button>
            </div>
          </section>
        )}
      </div>
    </aside>
  );
};

// インラインスタイル
const panelStyle: React.CSSProperties = {
  width: "260px",
  backgroundColor: "#27272a",
  borderLeft: "1px solid #3f3f46",
  color: "#f4f4f5",
  display: "flex",
  flexDirection: "column",
  fontSize: "13px",
  userSelect: "none",
};

const headerStyle: React.CSSProperties = {
  padding: "12px 16px",
  fontWeight: "bold",
  borderBottom: "1px solid #3f3f46",
  backgroundColor: "#18181b",
  fontSize: "14px",
};

const sectionTitleStyle: React.CSSProperties = {
  fontSize: "11px",
  fontWeight: "bold",
  textTransform: "uppercase",
  color: "#a1a1aa",
  marginBottom: "8px",
};

const gridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: "8px",
};

const fieldStyle: React.CSSProperties = {
  display: "flex",
  flexDirection: "column",
  gap: "4px",
};

const labelStyle: React.CSSProperties = {
  fontSize: "11px",
  color: "#a1a1aa",
};

const inputStyle: React.CSSProperties = {
  backgroundColor: "#18181b",
  border: "1px solid #3f3f46",
  borderRadius: "4px",
  color: "#ffffff",
  padding: "4px 8px",
  fontSize: "12px",
  outline: "none",
  width: "100%",
  boxSizing: "border-box",
};

const inputTextStyle: React.CSSProperties = {
  ...inputStyle,
  boxSizing: "border-box",
};
