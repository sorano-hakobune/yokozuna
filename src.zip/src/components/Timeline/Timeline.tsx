import { useState, useRef, useCallback } from "react";
import {
  useActiveComposition,
  useActiveLayers,
  useActiveCompositionId,
} from "@/stores/projectSelectors";
import { useProjectStore } from "@/stores/projectStore";
import { TimelineRuler } from "./TimelineRuler";
import { TimelinePlayhead } from "./TimelinePlayhead";
import { LayerRow } from "./LayerRow";
import "./timeline.css";

/**
 * タイムライン全体のコンテナ
 * - 左: レイヤー一覧
 * - 右: トラック + ルーラー + 再生ヘッド
 */
export function Timeline() {
  const composition = useActiveComposition();
  const layers = useActiveLayers();
  const compositionId = useActiveCompositionId();

  const addLayer = useProjectStore((s) => s.addLayer);

  // UI専用状態
  const [currentFrame, setCurrentFrame] = useState(0);
  const [zoom, setZoom] = useState(12); // px per frame
  const [scrollX, setScrollX] = useState(0);

  const tracksRef = useRef<HTMLDivElement>(null);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      setZoom((z) => Math.min(40, Math.max(4, z - e.deltaY * 0.05)));
    }
  }, []);

  if (!composition || !compositionId) {
    return <div className="timeline empty">No active composition</div>;
  }

  const totalWidth = composition.duration * zoom;

  return (
    <div className="timeline" onWheel={handleWheel}>
      {/* 左側: レイヤーコントロール */}
      <div className="layer-list">
        <div className="layer-list-header">
          <button onClick={() => addLayer()}>＋ Layer</button>
        </div>
        {layers.map((layer) => (
          <div key={layer.id} className="layer-header-row">
            <input
              type="checkbox"
              checked={layer.visible}
              onChange={(e) =>
                useProjectStore
                  .getState()
                  .updateLayer(layer.id, {
                    visible: e.target.checked,
                  })
              }
            />
            <span className="layer-name">{layer.name}</span>
          </div>
        ))}
      </div>

      {/* 右側: 時間軸エリア */}
      <div className="tracks-area" ref={tracksRef}>
        <TimelineRuler
          duration={composition.duration}
          zoom={zoom}
          scrollX={scrollX}
        />

        <div
          className="tracks-scroll"
          style={{ width: totalWidth }}
          onScroll={(e) => setScrollX(e.currentTarget.scrollLeft)}
        >
          {layers.map((layer) => (
            <LayerRow
              key={layer.id}
              layer={layer}
              zoom={zoom}
              currentFrame={currentFrame}
            />
          ))}
        </div>

        <TimelinePlayhead
          frame={currentFrame}
          zoom={zoom}
          onChange={setCurrentFrame}
          maxFrame={composition.duration}
        />
      </div>
    </div>
  );
}
